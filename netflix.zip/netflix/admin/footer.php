<div class="footer text-center mt-auto p-3">
  &copy; Copyrights Netflix India 2025
</div>