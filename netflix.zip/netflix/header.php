<?php
ob_start();
session_start();

if (!isset($_SESSION['loged']) && basename($_SERVER['PHP_SELF']) != 'login.php') {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Netflix India</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/style/style.css" rel="stylesheet">
</head>

<body class="page">

<nav class="navbar navbar-expand-lg navbar-dark bg-black sticky-top">
  <div class="container">

    <!-- Logo -->
    <a class="navbar-brand" href="index.php">
      <img src="assets/images/logo.png" alt="Logo" height="40">
    </a>

    <!-- Mobile Toggle -->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Navbar Content -->
    <div class="collapse navbar-collapse" id="navbarNav">

      <!-- Center Menu -->
      <ul class="navbar-nav mx-auto gap-3">
        <li class="nav-item"><a class="nav-link" href="tv.php">TV Shows</a></li>
        <li class="nav-item"><a class="nav-link" href="movies.php">Movies</a></li>
        <li class="nav-item"><a class="nav-link" href="tmovies.php">Trending Movies</a></li>
      </ul>

      <!-- Right Button -->
      <div class="d-flex">
        <?php if(!isset($_SESSION['loged'])) { ?>
            <a href="login.php" class="btn btn-danger">Login</a>
        <?php } else { ?>
            <a href="logout.php" class="btn btn-danger">Logout</a>
        <?php } ?>
      </div>

    </div>
  </div>
</nav>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>