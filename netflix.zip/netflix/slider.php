<div id="heroCarousel" class="carousel slide carousel-fade" data-bs-ride="carousel" data-bs-interval="5000">
  <div class="carousel-inner">

    <!-- Slide 1: Video -->
    <div class="carousel-item active" data-bs-interval="5000">
      <video class="d-block w-100" autoplay loop muted playsinline>
        <source src="assets/images/nn.mp4" type="video/mp4">
      </video>
      <div class="overlay"></div>
    </div>

    <!-- Slide 2: GIF/Image -->
    <div class="carousel-item" data-bs-interval="5000">
      <img class="d-block w-100" src="assets/images/logo.gif" alt="Logo">
      <div class="overlay"></div>
    </div>

    <!-- Slide 3: GIF/Image -->
    <div class="carousel-item" data-bs-interval="5000">
      <img class="d-block w-100" src="assets/images/lofo2.gif" alt="Logo">
      <div class="overlay"></div>
    </div>

  </div>

  <!-- Controls -->
  <button class="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next">
    <span class="carousel-control-next-icon"></span>
  </button>
</div>


