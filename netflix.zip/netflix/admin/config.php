<?php
$conn=mysqli_connect("localhost","root","","workshop") or die("Check the database");
?>